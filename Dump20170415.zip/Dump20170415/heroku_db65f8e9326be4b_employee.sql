CREATE DATABASE  IF NOT EXISTS `heroku_db65f8e9326be4b` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `heroku_db65f8e9326be4b`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: heroku_db65f8e9326be4b
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `Employee ID` int(11) NOT NULL AUTO_INCREMENT,
  `Zoo ID` int(11) NOT NULL,
  `Enclosure ID` int(11) DEFAULT NULL,
  `Shop ID` int(11) DEFAULT NULL,
  `First Name` varchar(45) NOT NULL,
  `Last Name` varchar(45) NOT NULL,
  `Full Name` varchar(45) NOT NULL,
  `Job Desciption` varchar(200) NOT NULL,
  `Hire Date` date NOT NULL,
  `Shifts` varchar(45) NOT NULL,
  `Salary` float NOT NULL,
  PRIMARY KEY (`Employee ID`),
  KEY `fk_Employee_Zoo_idx` (`Zoo ID`),
  KEY `fk_Employee_Shop1_idx` (`Shop ID`),
  KEY `fk_Employee_Exhibits1_idx` (`Enclosure ID`),
  CONSTRAINT `fk_Employee_Exhibits1` FOREIGN KEY (`Enclosure ID`) REFERENCES `enclosure` (`Enclosure`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Employee_Shop1` FOREIGN KEY (`Shop ID`) REFERENCES `shop` (`Shop ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Employee_Zoo` FOREIGN KEY (`Zoo ID`) REFERENCES `zoo` (`Zoo ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (7,1,NULL,2,'Roberto','Paige','Roberto Paige','Cashier','2017-03-24','Morning',10.25),(9,1,NULL,2,'Luke','Hart','','Cook','2017-03-27','Evening',12.75),(10,1,NULL,2,'Anne','Wilkins','','Cashier','2017-03-27','Evening',10.5),(11,1,3,NULL,'Jack','Bauer','','Animal Care Taker','2017-03-27','Morning',12.5),(12,1,4,NULL,'Wanda','Rutherford','','Animal Care Taker','2017-03-27','Evening',12.5),(13,1,5,NULL,'Alexandra','Roberts','','Animal Care Taker','2017-03-27','Morning',12.5),(14,1,6,NULL,'Kevin','Sutherland','','Animal Care Taker','2017-03-27','Evening',12.5),(15,1,7,NULL,'Gordon','Peake','','Animal Care Taker','2017-03-27','Morning',12.5),(16,1,8,NULL,'Cameron','Black','','Animal Care Taker','2017-03-27','Evening',12.5),(17,1,9,NULL,'Melanie','King','','Animal Care Taker','2017-03-27','Morning',12.5),(18,1,10,NULL,'Jennifer','Clarkson','','Animal Care Taker','2017-03-27','Evening',12.5),(19,1,11,NULL,'Lucas','Graham','','Animal Care Taker','2017-03-27','Morning',12.5),(212,1,NULL,3,'Jennifer','Snow','','Cashier','2017-03-30','Morning',10.25),(282,1,NULL,1,'Kimberly','Go','','Cashier','2017-03-31','Morning',9.5),(292,1,NULL,2,'Ryan','Turner','','Cook','2017-03-31','Morning',13.5),(312,1,10,1,'Harry','Potter','','Animal Care Taker','2017-03-31','Evening',11.3),(392,1,15,NULL,'Josh','Riot','','Cashier','2017-03-31','Morning',9.6),(412,1,10,NULL,'Cory','Yu','','Cashier','2017-03-31','Evening',10.8),(432,1,12,NULL,'Liz','Roe','','Animal Care Taker','2017-03-31','Evening',11.2),(462,1,5,NULL,'Anna','Pham','','Cashier','2017-03-31','Evening',12.25),(463,1,5,NULL,'Lizzie','Moe','Lizzie  Moe','Cashier','2017-01-05','Morning',13.35),(464,1,12,NULL,'Ryan','Gonzalez','Ryan Gonzalez','Animal Care Taker','2017-02-14','Morning',13.2),(467,1,12,NULL,'Roy','Cullen','Roy Cullen','Manager','2016-06-08','Morning',26.55),(470,1,NULL,1,'Terry','Colby','Terry Colby','Manager','2016-11-30','Evening',31.6);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `heroku_db65f8e9326be4b`.`employee_BEFORE_INSERT` BEFORE INSERT ON `employee` FOR EACH ROW
BEGIN
	DECLARE msg VARCHAR(255);
    DECLARE msg2 VARCHAR(255);
	IF NEW.Salary < 7.25           
	THEN 
		SET msg = 'Violation of Minimum Employee Salary.' ;
		SIGNAL SQLSTATE '45000' SET message_text = msg ;
	ELSE IF (NEW.`Job Desciption` = "Manager" && New.Salary < 25)
    THEN
		SET msg2 = 'Violation of Minimum Manager Salary.' ;
		SIGNAL SQLSTATE '45000' SET message_text = msg2 ;
	END IF;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `heroku_db65f8e9326be4b`.`employee_BEFORE_UPDATE` BEFORE UPDATE ON `employee` FOR EACH ROW
BEGIN
	DECLARE msg VARCHAR(255);
    DECLARE msg2 VARCHAR(255);
	IF NEW.Salary < 7.25           
	THEN 
		SET msg = 'Violation of Minimum Employee Salary.' ;
		SIGNAL SQLSTATE '45000' SET message_text = msg ;
	ELSE IF (NEW.`Job Desciption` = "Manager" && New.Salary < 25)
    THEN
		SET msg2 = 'Violation of Minimum Manager Salary.' ;
		SIGNAL SQLSTATE '45000' SET message_text = msg2 ;
	END IF;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-15 22:05:03
