CREATE DATABASE  IF NOT EXISTS `heroku_db65f8e9326be4b` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `heroku_db65f8e9326be4b`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: heroku_db65f8e9326be4b
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `animals`
--

DROP TABLE IF EXISTS `animals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `animals` (
  `Animal ID` int(11) NOT NULL AUTO_INCREMENT,
  `Exhibit ID` int(11) NOT NULL,
  `Diet Type ID` int(11) NOT NULL,
  `Animal Type ID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Age` int(11) NOT NULL,
  `Weight` varchar(45) NOT NULL,
  `Height` varchar(45) NOT NULL,
  `Gender` varchar(45) NOT NULL,
  PRIMARY KEY (`Animal ID`),
  KEY `fk_Animals_Exhibits1_idx` (`Exhibit ID`),
  KEY `fk_Animals_Diet Type1_idx` (`Diet Type ID`),
  KEY `fk_Animals_Animal Type1_idx` (`Animal Type ID`),
  CONSTRAINT `fk_Animals_Animal Type1` FOREIGN KEY (`Animal Type ID`) REFERENCES `animal type` (`Animal Type ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Animals_Diet Type1` FOREIGN KEY (`Diet Type ID`) REFERENCES `diet type` (`Diet Type ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Animals_Exhibits1` FOREIGN KEY (`Exhibit ID`) REFERENCES `enclosure` (`Enclosure`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animals`
--

LOCK TABLES `animals` WRITE;
/*!40000 ALTER TABLE `animals` DISABLE KEYS */;
INSERT INTO `animals` VALUES (1,1,1,1,'Zimba','Lion',5,'420 lbs','4.0 ft.','Male'),(2,1,1,1,'Luigi','Bobcat',4,'22 lbs','2.0 ft.','Male'),(3,2,3,3,'Walter','American Flamingo',4,'5 lbs','5.0 ft.','Male'),(4,2,3,3,'Mary','Greater Rhea',5,'40 lbs','4.0 ft.','Female'),(5,3,1,1,'Annie','Gray Wolf',3,'65 lbs','4.3 ft.','Female'),(6,3,2,1,'Bucky','American Beaver',3,'35 lbs','2.5 ft.','Male'),(7,4,1,1,'Zoom','Cheetah',6,'80 lbs','3.0 ft.','Male'),(8,4,2,1,'Stripes','Grevy\'s Zebra',7,'800 lbs','5.0 ft.','Female'),(9,5,2,1,'Rice','Asian Elephant',15,'8000 lbs','7.3 ft.','Female'),(10,6,1,2,'Crunch','American Alligator',10,'500 lbs','1.0 ft.','Male'),(11,6,1,2,'Rocky','Burmese Rock Python',12,'64 lbs','15  ft.','Male'),(12,7,3,5,'Lily','Japanese Koi',3,'16 lbs','20 in.','Female'),(13,7,2,5,'Nemo','Clown Fish',6,'.2 lbs','3 in.','Male'),(14,8,3,1,'Ush','Western Lowland Gorilla',18,'440 lbs','5.5 ft.','Male'),(15,8,3,1,'Rick','Orangutan',11,'110 lbs','4.2 ft.','Female'),(16,1,1,1,'Derreck','Sumatran Tiger',5,'350 lbs','8.0 ft.','Male'),(17,1,2,1,'Bryan','Blak-tailed Prairie Dog',7,'2 lbs','1.3 ft.','Female'),(18,1,1,1,'Linux','Caracal lynx',10,'30 lbs','3.3 ft.','Male'),(19,1,2,1,'Spike','North American Porcupine',2,'20 lbs','2.0 ft.','Male'),(20,2,3,3,'Emma','Emu',13,'81 lbs','5.1 ft.','Female'),(21,2,1,3,'Kenny','King Vulture',6,'7 lbs','2.5 ft.','Male'),(22,2,3,3,'Cody','Kori Bustard',11,'32 lbs','5.0 ft.','Male'),(23,2,3,3,'Emily','Stanley Crane',5,'9 lbs','3.5 ft.','Female'),(24,2,3,3,'Sarah','Roseate Spoonbill',10,'3 lbs','2.5 ft.','Female'),(25,3,1,3,'Baldie','Bald Eagle',31,'8 lbs','2.9 ft.','Male'),(26,3,3,3,'Cupper','Brown Pelican',11,'7 lbs','4.2 ft.','Male'),(27,3,1,1,'Raina','Gray Seal',16,'319 lbs','5.4 ft.','Female'),(28,3,1,1,'Jessica','Harbor Seal',7,'120 lbs','5.0 ft.','Female'),(29,3,3,3,'Remi','Common Raven',4,'2 lbs','2.0 ft.','Male'),(30,4,3,1,'Harry','Red River Hog',8,'100 lbs','2.0 ft.','Male'),(31,4,2,1,'Leslie','Lesser Kudu',5,'135 lbs','3.3 ft.','Female'),(32,4,2,1,'Larry','Sitatunga',9,'190 lbs','4.1 ft.','Male'),(34,6,1,2,'Tooth','Cuban Crocodile',8,'474 lbs','6.9 ft.','Male'),(35,6,1,2,'Slitherin','Eastern Indigo Snake',4,'6 lbs','6.5 ft.','Female'),(36,6,1,2,'Rawr','Gila Monster',3,'5 lbs','2.0 ft.','Male'),(37,6,1,2,'Gary','Komodo Dragon',18,'180 lbs','7.6 ft.','Male'),(38,8,3,1,'Carrie','White-Cheeked Gibbon',4,'11 lbs','1.7 ft.','Female'),(39,8,3,1,'Joe','Siamang',6,'13 lbs','3.2 ft.','Male'),(40,8,3,1,'Mankey','Red-Tailed Monkey',3,'7 lbs','1.3 ft.','Female'),(41,8,3,1,'Leonard','Ring-Tailed Lemur',14,'4 lbs','1.4 ft.','Male'),(42,7,2,5,'Coco','Twig catfish',2,'.5 lbs','5 in.','Female'),(43,7,1,5,'Dexter','Red-Bellied Piranha',4,'3 lbs','1 ft.','Male'),(44,7,2,1,'Ash','Donkey',6,'80 lbs','4.5 ft.','Male');
/*!40000 ALTER TABLE `animals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-15 22:05:02
